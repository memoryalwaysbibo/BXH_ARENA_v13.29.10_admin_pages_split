#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
npx --yes --package=node@22 --package=npm@10 --package=firebase-tools@15.28.1 -c 'node --version && npm --prefix functions ci && firebase deploy --only functions --project bxh-arena && node functions/seed-founder.js && echo "13.29.10 Functions 與創世者稱號資料更新完成"'
