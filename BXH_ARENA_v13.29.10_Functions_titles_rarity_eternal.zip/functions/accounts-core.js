'use strict';
const {createHash}=require('node:crypto');
const roles=new Set(['player','staff','admin','super_admin','tester','viewer']);
function normalizeRequest(data){
 if(!data||!Array.isArray(data.uids)||data.uids.length<1||data.uids.length>50)throw Error('select-1-to-50-accounts');
 const uids=[...new Set(data.uids)];if(uids.some(x=>typeof x!=='string'||!x||x.includes('/')||x.length>128))throw Error('invalid-account-id');uids.sort();
 const p=data.patch;if(!p||typeof p!=='object'||Array.isArray(p))throw Error('patch-required');
 const keys=Object.keys(p);if(!keys.length||keys.some(k=>!['role','active','isTestAccount','managementNote'].includes(k)))throw Error('invalid-account-field');
 const patch={};
 if('role'in p){if(!roles.has(p.role))throw Error('invalid-role');if(p.role==='super_admin'&&uids.length!==1)throw Error('super-admin-single-only');patch.role=p.role;}
 for(const k of ['active','isTestAccount'])if(k in p){if(typeof p[k]!=='boolean')throw Error('invalid-boolean');patch[k]=p[k];}
 if('managementNote'in p){if(typeof p.managementNote!=='string'||p.managementNote.length>500)throw Error('invalid-note');patch.managementNote=p.managementNote.trim();}
 if(typeof data.operationId!=='string'||!/^[a-zA-Z0-9_-]{1,100}$/.test(data.operationId))throw Error('invalid-operation-id');
 return {uids,patch,operationId:data.operationId,hash:createHash('sha256').update(JSON.stringify({uids,patch})).digest('hex')};
}
function makeAccountChanges(request,actorUid,actor,profiles,superCount){
 if(actor?.role!=='super_admin'||actor.active!==true||actor.isTestAccount===true)throw Error('super-admin-required');
 const results=[],updates=[];let count=superCount;
 for(const uid of request.uids){const old=profiles[uid];
  if(!old){results.push({uid,status:'failed',reason:'account-not-found'});continue;}
  const next={...old,...request.patch};
  // Tester is a managed test identity, never a route to super-admin authority.
  if(next.role==='tester'&&request.patch.isTestAccount===false){results.push({uid,status:'failed',reason:'tester-role-requires-test-identity'});continue;}
  if(next.role==='tester')next.isTestAccount=true;
  if(next.role==='super_admin'&&next.isTestAccount===true){results.push({uid,status:'failed',reason:'test-account-cannot-be-super-admin'});continue;}
  const wasSuper=old.role==='super_admin'&&old.active===true&&old.isTestAccount!==true,isSuper=next.role==='super_admin'&&next.active===true&&next.isTestAccount!==true;
  if(wasSuper&&!isSuper&&count<=1){results.push({uid,status:'failed',reason:'last-super-admin-protected'});continue;}
  if(wasSuper&&!isSuper)count--;if(!wasSuper&&isSuper)count++;
  const before={},after={};for(const k of ['role','active','isTestAccount','managementNote'])if(next[k]!==old[k]){before[k]=old[k]??null;after[k]=next[k];}
  if(!Object.keys(after).length){results.push({uid,status:'unchanged'});continue;}
  updates.push({uid,before,after});results.push({uid,status:'updated'});
 }
 return{results,updates,superCount:count};
}
module.exports={normalizeRequest,makeAccountChanges};
