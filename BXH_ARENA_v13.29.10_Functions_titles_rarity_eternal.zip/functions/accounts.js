'use strict';
// Shared single/batch account mutations; protected fields require this callable.
const {onCall,HttpsError}=require('firebase-functions/v2/https');
const {getFirestore}=require('firebase-admin/firestore');
const C=require('./accounts-core');
exports.changeManagedAccounts=onCall({region:'asia-east1',cors:true},async request=>{
 if(!request.auth)throw new HttpsError('unauthenticated','auth-required');
 let input;try{input=C.normalizeRequest(request.data);}catch(e){throw new HttpsError('invalid-argument',e.message);}
 const db=getFirestore(),uid=request.auth.uid,lock=db.doc('systemSettings/accountManagementControl'),operation=db.doc(`accountManagementOperations/${input.operationId}`);
 try{return await db.runTransaction(async tx=>{
  const actorRef=db.doc(`users/${uid}`);
  const [actor,control,existing,superUsers,...targets]=await Promise.all([tx.get(actorRef),tx.get(lock),tx.get(operation),tx.get(db.collection('users').where('role','==','super_admin')), ...input.uids.map(id=>tx.get(db.doc(`users/${id}`)))]);
  if(actor.data()?.role!=='super_admin'||actor.data()?.active!==true||actor.data()?.isTestAccount===true)throw Error('super-admin-required');
  if(existing.exists){const d=existing.data();if(d.actorUid!==uid||d.requestHash!==input.hash)throw Error('operation-conflict');return{ok:true,results:d.results,replayed:true};}
  const profiles=Object.fromEntries(targets.map(s=>[s.id,s.exists?s.data():null]));const count=superUsers.docs.filter(s=>s.data().active===true&&s.data().isTestAccount!==true).length;
  const plan=C.makeAccountChanges(input,uid,actor.data(),profiles,count),now=Date.now();
  for(const change of plan.updates)tx.update(db.doc(`users/${change.uid}`),{...change.after,managementUpdatedAt:now,managementUpdatedBy:uid});
  tx.set(lock,{revision:(control.data()?.revision||0)+1,updatedAt:now},{merge:true});
  tx.create(operation,{actorUid:uid,requestHash:input.hash,createdAt:now,results:plan.results,changes:plan.updates});
  return{ok:true,results:plan.results};
 });}catch(e){throw new HttpsError('failed-precondition',e.message);}
});
