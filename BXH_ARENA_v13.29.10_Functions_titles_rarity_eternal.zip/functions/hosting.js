'use strict';
const {onDocumentWritten}=require('firebase-functions/v2/firestore');
const {onCall,HttpsError}=require('firebase-functions/v2/https');
const {onSchedule}=require('firebase-functions/v2/scheduler');
const {getFirestore,FieldValue,FieldPath}=require('firebase-admin/firestore');
const {stateOf,completion}=require('./hosting-core');
const db=getFirestore();
async function keepAndCount(code){
 return db.runTransaction(async tx=>{
  const ref=db.doc(`tournaments/${code}`),snap=await tx.get(ref);if(!snap.exists)return null;
  const t=snap.data(),s=stateOf(t),uid=t.createdBy;
  if(!uid||typeof uid!=='string'||uid.includes('/'))return null;
  const ledger=db.doc(`hostCompletionLedger/${code}`),stats=db.doc(`hostStats/${uid}`);
  const [profile,prior,publicRoom]=await Promise.all([tx.get(db.doc(`users/${uid}`)),tx.get(ledger),tx.get(db.doc(`publicTournaments/${code}`))]);
  const summary=completion(t,profile.data());
  if(t.eventAuthority==='community'&&s.archiveStatus==='completed'&&t.expiresAt!=null){
   s.expiresAtMs=null;tx.update(ref,{expiresAt:null,data:JSON.stringify(s)});
   if(publicRoom.exists)tx.update(publicRoom.ref,{expiresAt:null});
  }
  if(summary&&!prior.exists){tx.create(ledger,{...summary,ownerUid:uid,eventCode:code,verifiedAt:FieldValue.serverTimestamp()});tx.set(stats,{completedHostedCount:FieldValue.increment(1),updatedAt:FieldValue.serverTimestamp()},{merge:true});}
  return summary?uid:null;
 });
}
// A persisted outbox decouples count commits from title evaluation retries.
async function run(code){const uid=await keepAndCount(code);if(uid)await db.doc(`hostAwardQueue/${uid}`).set({updatedAt:FieldValue.serverTimestamp()},{merge:true});}
exports.preserveCompletedRoomAndCountHost=onDocumentWritten({document:'tournaments/{code}',region:'asia-east1',retry:true},async e=>{if(e.data?.after.exists)await run(e.params.code);});
exports.syncMyHostingProgress=onCall({region:'asia-east1',cors:true,timeoutSeconds:540},async req=>{
 const uid=req.auth?.uid;if(!uid)throw new HttpsError('unauthenticated','auth-required');
 const p=await db.doc(`users/${uid}`).get();if(!p.exists||p.data().active!==true)throw new HttpsError('permission-denied','inactive-account');
 let last;do{let q=db.collection('tournaments').where('createdBy','==',uid).orderBy(FieldPath.documentId()).limit(100);if(last)q=q.startAfter(last);const page=await q.get();for(const d of page.docs)await run(d.id);last=page.size===100?page.docs.at(-1):null;}while(last);
 const stats=await db.doc(`hostStats/${uid}`).get();return {ok:true,completedHostedCount:Number(stats.data()?.completedHostedCount||0)};
});
// Also migrates existing completed rooms whose owners have not opened the new UI.
exports.preserveExistingCompletedRooms=onSchedule({schedule:'every 24 hours',region:'asia-east1',timeoutSeconds:540},async()=>{
 let last;do{let q=db.collection('tournaments').where('eventAuthority','==','community').orderBy(FieldPath.documentId()).limit(100);if(last)q=q.startAfter(last);const page=await q.get();for(const d of page.docs)if(stateOf(d.data()).archiveStatus==='completed')await run(d.id);last=page.size===100?page.docs.at(-1):null;}while(last);
});
