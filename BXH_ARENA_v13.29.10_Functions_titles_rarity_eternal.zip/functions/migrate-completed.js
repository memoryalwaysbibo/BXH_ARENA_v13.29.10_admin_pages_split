'use strict';
const {initializeApp}=require('firebase-admin/app');
const {getFirestore}=require('firebase-admin/firestore');
initializeApp({projectId:'bxh-arena'});
require('./hosting').preserveExistingCompletedRooms.run()
 .then(()=>console.log('已完成房間保留整理；可驗證的主辦場數已同步。'))
 .catch(e=>{console.error('整理未完成，可安全重新執行：',e.message);process.exitCode=1;})
 .finally(()=>getFirestore().terminate());
