'use strict';
function stateOf(t){try{return typeof t.data==='string'?JSON.parse(t.data):t.data||{};}catch{return {};}}
function completion(t,profile){
 const s=stateOf(t),players=s.players||[],matches=(s.matches||[]).filter(m=>!m.isBye);
 if(!profile||profile.active!==true||profile.role==='tester'||profile.isTestAccount===true||t.testMode||s.testMode||t.eventAuthority==='test'||t.createdByRole==='tester')return null;
 if(t.systemClosed||s.meta?.eventCancelled||t.eventCancelled||t.tournamentPhase==='cancelled'||(s.systemClosure&&!s.systemClosure.restoredAt))return null;
 if(s.archiveStatus!=='completed'||players.length<2||!matches.length||matches.some(m=>!m.completed))return null;
 const ids=new Set(players.map(p=>p.id));
 if(!matches.some(m=>m.a?.playerId&&m.b?.playerId&&m.a.playerId!==m.b.playerId&&ids.has(m.a.playerId)&&ids.has(m.b.playerId)&&[m.a.playerId,m.b.playerId].includes(m.winnerId)&&!m.forfeit&&!m.walkover&&!m.disqualified))return null;
 return {name:s.meta?.name||t.name||'',eventDate:s.meta?.date||t.eventDate||'',playerCount:players.length,completedAt:Number(s.completedAt)||Date.now(),eventAuthority:t.eventAuthority||s.meta?.eventAuthority||'official'};
}
module.exports={stateOf,completion};
